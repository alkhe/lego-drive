package edu.mbhs.fuzzylogic.sensors;

import lejos.nxt.ColorSensor;
import lejos.nxt.LightSensor;

public class SensorHandler {
	private SensorReadingThread thread;
	private ColorSensor leftColorSensor, rightColorSensor;
	private LightSensor centerLightSensor;
	
	//most recently collected data; should only be modified or read with a lock on this
	private SensorData data;
	
	public SensorHandler(ColorSensor leftColorSensor, ColorSensor rightColorSensor, LightSensor centerLightSensor) {
		this.leftColorSensor = leftColorSensor;
		this.rightColorSensor = rightColorSensor;
		this.centerLightSensor = centerLightSensor;
		
		this.thread = new SensorReadingThread();
	}
	
	public synchronized void startReadingSensors() {
		if(!thread.isAlive())
			thread.start();
	}
	
	public void stopReadingSensors() {
		if(thread.isAlive() && !thread.isInterrupted())
			thread.interrupt();
	}
	
	public synchronized SensorData getSensorData() {
		return data;
	}
	
	private class SensorReadingThread extends Thread {
		public void run() {
			while (!isInterrupted()) {
				ColorSensor.Color leftColor = leftColorSensor.getColor();
				ColorSensor.Color rightColor = rightColorSensor.getColor();
				int centerIntensity = centerLightSensor.getLightValue();
				
				synchronized (SensorHandler.this) {
					data = new SensorData(leftColor, rightColor, centerIntensity);
				}
				
				try {
					Thread.sleep(50);
				} catch (InterruptedException e) {
					break;
				}
			}
		}
	}
	
	public class SensorData {
		//for each sensor, the last values read in
		private ColorSensor.Color leftColor;
		private ColorSensor.Color rightColor;
		private int centerIntensity;
		
		public SensorData(ColorSensor.Color leftColor, ColorSensor.Color rightColor, int centerIntensity) {
			this.leftColor = leftColor;
			this.rightColor = rightColor;
			this.centerIntensity = centerIntensity;
		}
		
		public ColorSensor.Color getLeftColor() {
			return leftColor;
		}
		
		public ColorSensor.Color getRightColor() {
			return rightColor;
		}
		
		public int getCenterIntensity() {
			return centerIntensity;
		}
	}
}
