package edu.mbhs.fuzzylogic.behavior;

import edu.mbhs.fuzzylogic.RobotDriver;
import edu.mbhs.fuzzylogic.sensors.SensorHandler;

public abstract class Behavior {
	protected Behavior nextBehavior;
	
	public abstract void execute(RobotDriver pilot, SensorHandler sensorHandler);
	
	public Behavior getNextBehavior() {
		return nextBehavior;
	}
	
	public void setNextBehavior(Behavior next) {
		this.nextBehavior = next;
	}
}
