package edu.mbhs.fuzzylogic.behavior;

import edu.mbhs.fuzzylogic.Constants;
import edu.mbhs.fuzzylogic.RobotDriver;
import edu.mbhs.fuzzylogic.sensors.SensorHandler;

public class BackwardStraight extends Behavior {
	private float stopDistance;
	private float speed;
	private float initialLeftDistance;
	private float initialRightDistance;
	
	public BackwardStraight(String ... params) {
		// Param 0: speed (reads as slow/fast; translate into a negative float)
		// Param 1: distance
		speed = (params[0].toLowerCase().trim().charAt(0)=='f')?-Constants.FAST_SPEED:-Constants.SLOW_SPEED;
		stopDistance = Float.parseFloat(params[1].trim());
	}
	
	@Override
	public void execute(RobotDriver pilot, SensorHandler sensorHandler) {
		if (Constants.DEBUG || Constants.DEBUG_BEHAVIORS)
			System.out.println("Entering BackwardStraight");
		pilot.stop();
		initDistance(pilot, sensorHandler);
		
		boolean done = false;
		while (!done) {
			pilot.arcadeDrive(speed, 0);
			
			done = Math.abs((pilot.getLeftDistance()-initialLeftDistance)+(pilot.getRightDistance()-initialRightDistance))/2>=stopDistance;
		}
		if (Constants.DEBUG || Constants.DEBUG_BEHAVIORS)
			System.out.println("Exiting BackwardStraight");
	}
	
	private void initDistance(RobotDriver pilot, SensorHandler sensorHandler) {
		initialLeftDistance = pilot.getLeftDistance();
		initialRightDistance = pilot.getRightDistance();
	}
}
