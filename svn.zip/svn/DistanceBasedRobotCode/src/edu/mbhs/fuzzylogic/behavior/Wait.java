package edu.mbhs.fuzzylogic.behavior;

import edu.mbhs.fuzzylogic.Constants;
import edu.mbhs.fuzzylogic.RobotDriver;
import edu.mbhs.fuzzylogic.sensors.SensorHandler;

public class Wait extends Behavior {
	private long time;
	
	public Wait(String ... params) {
		//1 parameter; time in seconds as a float
		time = (long)(1000 * Float.parseFloat(params[0].trim()));
	}
	
	@Override
	public void execute(RobotDriver pilot, SensorHandler sensorHandler) {
		if (Constants.DEBUG || Constants.DEBUG_BEHAVIORS)
			System.out.println("Entering Wait");
		pilot.stop();
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) { }
		if (Constants.DEBUG || Constants.DEBUG_BEHAVIORS)
			System.out.println("Exiting Wait");
	}

}
