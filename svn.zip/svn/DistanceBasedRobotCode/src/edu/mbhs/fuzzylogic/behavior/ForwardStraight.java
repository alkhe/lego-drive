package edu.mbhs.fuzzylogic.behavior;

import lejos.nxt.ColorSensor.Color;
import edu.mbhs.fuzzylogic.Constants;
import edu.mbhs.fuzzylogic.RobotDriver;
import edu.mbhs.fuzzylogic.Utilities;
import edu.mbhs.fuzzylogic.sensors.SensorHandler;
import edu.mbhs.fuzzylogic.sensors.SensorHandler.SensorData;

public class ForwardStraight extends Behavior {
	private float stopDistance;
	private float initialLeftDistance = Integer.MAX_VALUE;
	private float initialRightDistance = Integer.MAX_VALUE;
	private float speed;
	private StopCondition stopCondition;
	private LineFollowingMode lineFollowingMode;
	
	private enum StopCondition {
		DISTANCE,
		RED,
		WHITE,
		BLUE
	}
	
	private enum LineFollowingMode {
		LEFT,
		RIGHT,
		NONE
	}
	
	public ForwardStraight(String ... params) {
		//Param 0: fast/slow (read based on first letter)
		//Param 1: line following mode (left, right, none)
		//Param 2: stop condition (red, white, distance; read first letter)
		//Param 3: (if distance) the distance (float)
		speed = (params[0].toLowerCase().trim().charAt(0)=='f')?Constants.FAST_SPEED:Constants.SLOW_SPEED;
		if (params[1].toLowerCase().trim().charAt(0)=='l')
			lineFollowingMode = LineFollowingMode.LEFT;
		else if (params[1].toLowerCase().trim().charAt(0)=='r')
			lineFollowingMode = LineFollowingMode.RIGHT;
		else
			lineFollowingMode = LineFollowingMode.NONE;
		if (params[2].toLowerCase().trim().charAt(0)=='d')
			stopCondition = StopCondition.DISTANCE;
		else if (params[2].toLowerCase().trim().charAt(0)=='w')
			stopCondition = StopCondition.WHITE;
		else if (params[2].toLowerCase().trim().charAt(0)=='b')
			stopCondition = StopCondition.BLUE;
		else
			stopCondition = StopCondition.RED;
		if (stopCondition==StopCondition.DISTANCE)
			stopDistance = Float.parseFloat(params[3].trim());
	}
	
	@Override
	public void execute(RobotDriver pilot, SensorHandler sensorHandler) {
		if (Constants.DEBUG || Constants.DEBUG_BEHAVIORS)
			System.out.println("Entering ForwardStraight");
		if (stopCondition==StopCondition.DISTANCE)
			initDistance(pilot, sensorHandler);
		boolean done = false;
		
		long lastTimeOnRoad = System.currentTimeMillis();
		while (!done) {
			SensorData data = sensorHandler.getSensorData();
			float turn = 0;
			if(lineFollowingMode==LineFollowingMode.LEFT || lineFollowingMode == LineFollowingMode.RIGHT) {
				Color c = (lineFollowingMode==LineFollowingMode.LEFT)?data.getLeftColor():data.getRightColor();
				if (c.getColor()==Color.WHITE || c.getColor()==Color.YELLOW || c.getColor()==Color.GREEN || c.getColor()==Color.BLUE || c.getColor()==Color.RED) {
					turn = speed/15 * (1+(System.currentTimeMillis() - lastTimeOnRoad)/1000f*10);//turn right; as time passes turn right faster
				}
				else {
					turn = -speed/20;
					lastTimeOnRoad = System.currentTimeMillis();
				}
				if (lineFollowingMode == LineFollowingMode.RIGHT)
					turn = -turn;
			}

			pilot.arcadeDrive(speed, turn);
			
			switch(stopCondition) {
			case DISTANCE:
				done = Math.abs((pilot.getLeftDistance()-initialLeftDistance)+(pilot.getRightDistance()-initialRightDistance))/2>=stopDistance;
				break;
			case RED:
				done = Utilities.isRedIntensity(data.getCenterIntensity())
					|| data.getRightColor().getColor()==Color.RED
					|| data.getLeftColor().getColor()==Color.RED;
				break;
			case WHITE:
//				done = Utilities.isWhiteIntensity(data.getCenterIntensity())
//					|| data.getRightColor().getColor()==Color.WHITE;
				done = data.getRightColor().getColor()==Color.WHITE && data.getLeftColor().getColor()==Color.WHITE;
				break;
			case BLUE:
				done = data.getRightColor().getColor()==Color.BLUE || data.getLeftColor().getColor()==Color.BLUE;
				break;
			default://shouldn't happen
				done = true;
				break;
			}
			
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		if (Constants.DEBUG || Constants.DEBUG_BEHAVIORS)
			System.out.println("Exiting ForwardStraight");
	}

	private void initDistance(RobotDriver pilot, SensorHandler sensorHandler) {
		initialLeftDistance = pilot.getLeftDistance();
		initialRightDistance = pilot.getRightDistance();
	}
}
