package edu.mbhs.fuzzylogic.behavior;

import edu.mbhs.fuzzylogic.Constants;
import edu.mbhs.fuzzylogic.RobotDriver;
import edu.mbhs.fuzzylogic.sensors.SensorHandler;

public class TurnRight extends Behavior {
	private float angle;
	
	public TurnRight(String ... params) {
		//one parameter, positive number of degrees to turn
		angle = Math.abs(Float.parseFloat(params[0].trim()));
	}
	
	@Override
	public void execute(RobotDriver pilot, SensorHandler sensorHandler) {
		if (Constants.DEBUG || Constants.DEBUG_BEHAVIORS)
			System.out.println("Entering Turn Right");
		pilot.stop();
		pilot.rotate(angle);
		if (Constants.DEBUG || Constants.DEBUG_BEHAVIORS)
			System.out.println("Exiting TurnRight");
	}

}
