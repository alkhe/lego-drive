package edu.mbhs.fuzzylogic;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;

import edu.mbhs.fuzzylogic.behavior.BackwardStraight;
import edu.mbhs.fuzzylogic.behavior.Behavior;
import edu.mbhs.fuzzylogic.behavior.ForwardStraight;
import edu.mbhs.fuzzylogic.behavior.TurnLeft;
import edu.mbhs.fuzzylogic.behavior.TurnRight;
import edu.mbhs.fuzzylogic.behavior.Wait;

public class GraphParser{

	private Hashtable<String, Node> nodes;
	private List<Node> nodeValues;

	private Node startNode;

	private void ensureExistence(String... names){
		for(String name:names)
			if(nodes.get(name)==null)
				nodes.put(name, new Node());
	}

	public GraphParser(String graph_filename, String constants_filename, String startNodeName) throws IOException{

		// Read substitution constants
		FileInputStream in=new FileInputStream(new File(constants_filename));
		List<String> vars=new ArrayList<String>(), subs=new ArrayList<String>();
		String str="";
		int val;
		boolean value=false;
		while((val=in.read())!=-1){
			char c=(char)val;
			if(c == '\n'){
				(value?subs:vars).add(str);
				str="";
				value = !value;
			}else
				str += c;
		}
		for(int i=0;i<vars.size();i++)
			System.out.println(vars.get(i)+":"+subs.get(i));
		in.close(); // Close constants file
		
		// Read graph
		in=new FileInputStream(new File(graph_filename));
		List<String[]> contents=new ArrayList<String[]>();
		str="";
		List<String> cmd=new ArrayList<String>();
		boolean comment = false;
		while((val=in.read())!=-1){
			char c=(char)val;
			comment = (comment || c=='#') && (c!='\n');
			if (comment)
				continue;
			if(c==' ' || c=='\t' || c=='\n'){
				if(!str.isEmpty())
					cmd.add(str);
				str="";
				if(c=='\n'){
					if(!cmd.isEmpty())
						contents.add(cmd.toArray(new String[cmd.size()]));
					cmd.clear();
				}
			}else
				str += c;
		}
		//TODO:make substitutions up there
		
		// Populate table
		nodes=new Hashtable<String, Node>();
		Node from, to;
		for(String[] command:contents){
			ensureExistence(command[0], command[1]);
			from=nodes.get(command[0]);
			to=nodes.get(command[1]);
			from.addEdge(new Edge(from, to, Float.parseFloat(command[2]), command));
		}

		// Close graph file
		in.close();

		// Break up map for reasons I don't have time to figure out how to say
		nodeValues=new ArrayList<Node>();
		Enumeration<String> keys=nodes.keys();
		while(keys.hasMoreElements())
			nodeValues.add(nodes.get(keys.nextElement()));

		// Set starting node
		startNode=nodes.get(startNodeName);
	}

	public Behavior[] pathTo(String targetName){

		Node target=nodes.get(targetName);

		// Reset nodes
		for(Node node:nodeValues){
			node.reset();
		}
		startNode.setTime(0, null);

		// Dijkstra's algorithm
		Node current=startNode;
		while(true){
			// current is the lowest unmarked vertex (or the starting vertex)
			current.mark();
			if(current == target){
				// Found it!
				List<Behavior> stuffToDo=new ArrayList<Behavior>();
				do{
					Edge edge=current.getUsedEdge();
					String[] command=edge.getCommand();
					// Line: <from> <to> <time> <behavior type> [everything left sent to behavior]
					String type=command[3];
					String[] params=new String[command.length-4];
					for(int i=4;i<command.length;i++)
						params[i-4]=command[i];
					switch(type.charAt(0)){
					case 'S':
					case 'C':
						stuffToDo.add(new ForwardStraight(params));
						break;
					case 'B':
						stuffToDo.add(new BackwardStraight(params));
						break;
					case 'L':
						stuffToDo.add(new TurnLeft(params));
						break;
					case 'R':
						stuffToDo.add(new TurnRight(params));
					case 'W':
						stuffToDo.add(new Wait(params));
						break;
					default:
						System.err.println("FATAL: Invalid behavior type: \""+type+"\"");
						System.exit(1);
					}
					current=edge.getStart();
				}while(current != startNode);
				startNode=target;
				Behavior[] result = new Behavior[stuffToDo.size()];
				for (int i=0;i<stuffToDo.size();i++)
					result[result.length-1-i]=stuffToDo.get(i);
				return result;
			}

			// Update time for each edge if the fastest time so far is through our current node
			for(Edge edge:current.getEdges()){
				Node next=edge.getEnd();
				float time=current.getTime() + edge.getTime();
				if(time < next.getTime())
					next.setTime(time, edge);
			}

			// Find the next node
			current=null;
			float min=Float.POSITIVE_INFINITY;
			for(Node node:nodeValues){
				float time=node.getTime();
				if(!node.isMarked() && time < min){
					current=node;
					min=time;
				}
			}
			if(current==null)
				return null; // No path found; this should never happen if the map is complete and correct.
		}
	}

	private class Node{

		private float time;
		private boolean mark;

		private Edge from;

		private List<Edge> edges;

		public void reset(){
			time=Float.POSITIVE_INFINITY;
			mark=false;
		}

		public Node(){
			edges=new ArrayList<Edge>();
		}

		public void addEdge(Edge edge){
			edges.add(edge);
		}

		public List<Edge> getEdges(){
			return edges;
		}

		public void setTime(float t, Edge f){
			time=t;
			from=f;
		}

		public float getTime(){
			return time;
		}

		public Edge getUsedEdge(){
			return from;
		}

		public void mark(){
			mark=true;
		}

		public boolean isMarked(){
			return mark;
		}
	}

	private class Edge{

		private String[] command;
		private Node start, end;
		private float time;

		public Edge(Node s, Node e, float t, String[] c){
			start=s;
			end=e;
			time=t;
			command=c;
		}

		public Node getStart(){
			return start;
		}

		public Node getEnd(){
			return end;
		}

		public float getTime(){
			return time;
		}

		public String[] getCommand(){
			return command;
		}
	}
}
