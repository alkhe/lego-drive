package edu.mbhs.fuzzylogic;

import lejos.nxt.Button;
import lejos.nxt.ColorSensor;
import lejos.nxt.LightSensor;
import lejos.nxt.Motor;
import lejos.nxt.NXTRegulatedMotor;
import lejos.nxt.SensorPort;
//import lejos.nxt.Sound;
import lejos.robotics.Color;
import edu.mbhs.fuzzylogic.behavior.Behavior;
import edu.mbhs.fuzzylogic.sensors.SensorHandler;
import edu.mbhs.fuzzylogic.sensors.SensorHandler.SensorData;

public class Runner {
	public static final NXTRegulatedMotor left = Motor.B, right = Motor.A;
	public static final ColorSensor csLeft = new ColorSensor(SensorPort.S2);
	public static final ColorSensor csRight= new ColorSensor(SensorPort.S1);
	public static final LightSensor lsMiddle= new LightSensor(SensorPort.S3);

	public static void main(String[] args) {
		//initialize sensors
		csLeft.setFloodlight(Color.WHITE);
		csRight.setFloodlight(Color.WHITE);
		SensorHandler sensorHandler = new SensorHandler(csLeft, csRight, lsMiddle);
		sensorHandler.startReadingSensors();

		//initialize drive
		left.setAcceleration(500);
		right.setAcceleration(500);
		RobotDriver pilot = new RobotDriver(left, right, Constants.WHEEL_CIRCUMFERENCE, Constants.WHEEL_SEPARATION, true, true);

		//initialize behaviors
		Behavior[] behaviors = BehaviorList.behaviors;
		
		/*GraphParser graph=null;
		try{
			graph=new GraphParser("graph.txt", "constants.txt", "0");
		}catch(IOException ex){
			ex.printStackTrace();
			Button.waitForPress();
			System.exit(2);
		}
		Behavior[] behaviors=graph.pathTo("2");*/
		
		for (int i=0;i<behaviors.length-1;i++)
			behaviors[i].setNextBehavior(behaviors[i+1]);
		Behavior b = behaviors[0];

		//initialize Leeroy
		System.out.println("Let's do this!");
		Button.waitForPress();
		System.out.println("Leeroy Jenkins!");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		//run behaviors
		while (b!=null) {
			b.execute(pilot, sensorHandler);
			b = b.getNextBehavior();
//			Sound.beep();
			if (b!=null && Constants.DEBUG_BEHAVIORS) {
				pilot.stop();
				Button.waitForPress();
			}
		}

		//done
		pilot.stop();

		//DEBUG: print sensor info until button press
		while(Button.readButtons()==0) {
			SensorData data = sensorHandler.getSensorData();
			switch (data.getLeftColor().getColor()) {
			case Color.BLACK:
				System.out.print("Black");
				break;
			case Color.BLUE:
				System.out.print("Blue");
				break;
			case Color.RED:
				System.out.print("Red");
				break;
			case Color.YELLOW:
				System.out.print("Yellow");
				break;
			case Color.WHITE:
				System.out.print("White");
				break;
			default:
				System.out.print("Other");
				break;
			}
			System.out.println("\t"+(int)data.getCenterIntensity());
		}

		sensorHandler.stopReadingSensors();
	}
}
