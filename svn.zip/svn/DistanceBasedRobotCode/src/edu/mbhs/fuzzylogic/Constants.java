package edu.mbhs.fuzzylogic;


public class Constants {
	public static final float WHEEL_CIRCUMFERENCE = 25.5f;//cm
	public static final float FAST_SPEED = 16.66f;//10 m/min = 16.66 cm/sec
	public static final float SLOW_SPEED = 10f;//6 m/min = 10 cm/sec
	public static final float WHEEL_SEPARATION = 10f;//cm
	public static final boolean DEBUG = false;
	public static final boolean DEBUG_BEHAVIORS = false;

}
