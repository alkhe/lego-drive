package edu.mbhs.fuzzylogic;

public class Utilities {
	public static boolean isRedIntensity(int intensity) {
		//TODO calibrate range
		return 47<=intensity && intensity <=53;
	}
	
	public static boolean isWhiteIntensity(int intensity) {
		//FIXME: find the right range for this
		return intensity >= 54;
	}
}
