package edu.mbhs.fuzzylogic;

import lejos.nxt.NXTRegulatedMotor;

public class RobotDriver {
	private NXTRegulatedMotor left, right;
	private float wheelSeparation;
	private float leftScale, rightScale;//convert cm/s to degrees/s
	
	public RobotDriver(NXTRegulatedMotor left, NXTRegulatedMotor right, float wheelCircumference, float wheelSeparation, boolean invertLeft, boolean invertRight) {
		this.left = left;
		this.right = right;
		this.wheelSeparation = wheelSeparation;
		
		leftScale = 360f/wheelCircumference * ((invertLeft)?-1:1);
		rightScale = 360f/wheelCircumference * ((invertRight)?-1:1);
	}

	public float getLeftDistance() {
		return left.getTachoCount()/leftScale;
	}
	
	public float getRightDistance() {
		return right.getTachoCount()/rightScale;
	}
	
	public void arcadeDrive(float speed, float turn) {
		float leftSpeed = (speed + turn) * leftScale;
		float rightSpeed = (speed - turn) * rightScale;
		left.setSpeed(leftSpeed);
		right.setSpeed(rightSpeed);
		if (leftSpeed>=0)
			left.forward();
		else
			left.backward();
		if (rightSpeed>=0)
			right.forward();
		else
			right.backward();
	}
	
	public void rotate(float angle) {
		float rotationCircumference = wheelSeparation * (float)Math.PI;
		float wheelDistance = angle/360f*rotationCircumference;
		int leftDegrees = (int) (wheelDistance * leftScale);
		int rightDegrees = (int) (-wheelDistance * rightScale);
		
		left.rotate(leftDegrees, true);
		right.rotate(rightDegrees);		
	}
	
	public void stop() {
		int leftAcceleration = left.getAcceleration();
		int rightAcceleration = right.getAcceleration();
		left.setAcceleration(6000);
		right.setAcceleration(6000);
		left.stop(true);
		right.stop();
		left.setAcceleration(leftAcceleration);
		right.setAcceleration(rightAcceleration);
		
	}
}
