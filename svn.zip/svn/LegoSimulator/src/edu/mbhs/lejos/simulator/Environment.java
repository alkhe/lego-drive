package edu.mbhs.lejos.simulator;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import javax.swing.JPanel;

import edu.mbhs.lejos.simulator.decoration.RobotDecoration;

public class Environment extends JPanel {
	private static final long serialVersionUID = 1638111050124372860L;
	private BufferedImage background;
	private float cmPerMapPixel;
	private float panelPixelsPerMapPixel = .12f;
	
	private ArrayList<Robot> robots;

	public Environment(BufferedImage background, float cmPerMapPixel) {
		this.background = background;
		this.cmPerMapPixel = cmPerMapPixel;
		
		robots = new ArrayList<Robot>();

		setPreferredSize(new Dimension(background.getWidth(), background.getHeight()));
	}

	public void addRobot(Robot r) {
		robots.add(r);
		r.setEnvironment(this);
	}

	public void paint(Graphics g1) {
		Graphics2D g = (Graphics2D) g1;

		AffineTransform orig = g.getTransform();
		//flip so the screen is the coordinate plane the way we normally think of it
		g.translate(0, getHeight()/2);
		g.scale(1, -1);
		g.translate(0, -getHeight()/2);
		
		//draw background filling the screen
		g.drawImage(background, 0, (int)(background.getHeight()*panelPixelsPerMapPixel), (int)(background.getWidth()*panelPixelsPerMapPixel), 0, 0, 0, background.getWidth(), background.getHeight(), null);
		
		for (Robot r:robots) {
			AffineTransform temp = g.getTransform();

			g.scale(panelPixelsPerMapPixel/cmPerMapPixel, panelPixelsPerMapPixel/cmPerMapPixel);
			//translate to robot's center
			g.translate(r.getX(), r.getY());			
			//rotate to robot's angle
			g.rotate(r.getAngle());
			//draw robot's decorations
			for (RobotDecoration d:r.getDecorations()) {
				d.renderDecoration(g);
			}

			//undo transformations
			g.setTransform(temp);
		}
		g.setTransform(orig);
	}

	public Color getColor(double x, double y) {
		//determine image coordinates, get color
		float panelX = (float) (x / cmPerMapPixel * panelPixelsPerMapPixel);
		float panelY = (float) (y / cmPerMapPixel * panelPixelsPerMapPixel);
		
		int imageX = (int)(panelX / panelPixelsPerMapPixel);
		int imageY = (int)(panelY / panelPixelsPerMapPixel);

		imageY = background.getHeight() - imageY;
		
		if (imageX<0 || imageY<0 || imageX >= background.getWidth() || imageY >= background.getHeight())
			return Color.white;
		else
			return new Color(background.getRGB(imageX, imageY));
		
	}
}
