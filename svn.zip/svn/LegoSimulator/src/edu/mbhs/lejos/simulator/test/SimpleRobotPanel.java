package edu.mbhs.lejos.simulator.test;

import java.awt.Dimension;
import java.awt.image.BufferedImage;

import edu.mbhs.lejos.simulator.Environment;
import edu.mbhs.lejos.simulator.Robot;


public class SimpleRobotPanel extends Environment {
	private static final long serialVersionUID = 7527113144975005668L;
	private RobotTesterThread robotThread;
	private Robot robot;
	private boolean done;
//	private static int wheelSize = 4;
	
	public SimpleRobotPanel(RobotTesterThread robotThread, BufferedImage background, float cmPerMapPixel) {
		super(background, cmPerMapPixel);
		
		this.robotThread = robotThread;
		this.robot = robotThread.getRobot();
		this.done = false;
		
		this.addRobot(robot);
		
		setPreferredSize(new Dimension(42*30,10*30));//TODO remove this; temporarily setting size for convenience
		
		new Thread(new Runnable() {
			public void run() {
				//wait 1.5 seconds; then
				//a) launch robot code in a new thread (that sets the "done" variable when done)
				//b) start simulating
				try {
					Thread.sleep(1500);
				} catch (InterruptedException e) { }
				
				new Thread(new Runnable() {
					public void run() {
						SimpleRobotPanel.this.robotThread.run();//not start(); use this thread
						done = true;
					}
				}).start();
				
				long lastTime = System.currentTimeMillis();
				while (!done) {
					long time = System.currentTimeMillis();
					float dt = (time-lastTime)/1000f;
					lastTime = time;
					robot.move(dt);
					repaint();
					try {
						Thread.sleep(50);
					} catch (InterruptedException e) { }
				}
			}
		}).start();
	}
}