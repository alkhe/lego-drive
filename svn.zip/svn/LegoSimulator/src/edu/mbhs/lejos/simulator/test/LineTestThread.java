package edu.mbhs.lejos.simulator.test;

import java.awt.Dimension;

import lejos.nxt.ColorSensor;
import lejos.nxt.ColorSensor.Color;
import lejos.nxt.Motor;
import lejos.nxt.NXTRegulatedMotor;
import lejos.nxt.SensorPort;
import edu.mbhs.lejos.simulator.Robot;
import edu.mbhs.lejos.simulator.decoration.FrameDecoration;

/**
 * Tests robot movement by moving the robot in a straight line and stopping.
 * @author dakaufma
 */
public class LineTestThread extends RobotTesterThread {
	private Robot robot;
	private long moveTime;
	private ColorSensor colorSensor;
	private NXTRegulatedMotor leftMotor, rightMotor;
	private float lScale, rScale;
	private float speed;
	
	public LineTestThread() {
		this((int)(42 * 30.48f));//42 feet in cm
	}
	
	public LineTestThread(long distance) {
		leftMotor = Motor.A;
		rightMotor = Motor.B;
		lScale = 5;
		rScale = 5;//each wheel has a circumference of 5 cm
		speed = 20;//cm per second
		this.moveTime = (long) (distance/speed*1000);
		colorSensor = new ColorSensor(SensorPort.S1);
		robot = new Robot(0, 200, (float)-Math.PI/2, 10, lScale, rScale, leftMotor, rightMotor);
		robot.addDecoration(new FrameDecoration(10, 20, -5, -10, java.awt.Color.WHITE));
		robot.addColorSensor(colorSensor, 0, 10);//front center of robot
	}
	
	@Override
	public Robot getRobot() {
		return robot;
	}

	@Override
	public void run() {
		Thread colorThread = new Thread(new Runnable() {
			public void run() {
//				String colorNames[] = {"None", "Red", "Green", "Blue", "Yellow",
//                        "Megenta", "Orange", "White", "Black", "Pink",
//                        "Grey", "Light Grey", "Dark Grey", "Cyan"};
				while (!isInterrupted()) {
//					int color = colorSensor.getColorID();
//					String colorName = colorNames[color + 1];
//					System.out.print(colorName+"\t");
					Color c = colorSensor.getColor();
					System.out.println(c.getRed() + "\t" + c.getGreen() + "\t" + c.getBlue());
					try {Thread.sleep(10);}
					catch (InterruptedException e) {
						break;
					}
				}
			}
		});
		colorThread.start();
		leftMotor.setSpeed(speed * 360/lScale);
		rightMotor.setSpeed(speed * 360/rScale);
		leftMotor.forward();
		rightMotor.forward();
		try {
			Thread.sleep(moveTime);
		} catch (InterruptedException e) { }
		leftMotor.stop();
		rightMotor.stop();
		colorThread.interrupt();
	}

	@Override
	public Dimension getDesiredEnvironmentSize() {
		return new Dimension(500,500);
	}

}
