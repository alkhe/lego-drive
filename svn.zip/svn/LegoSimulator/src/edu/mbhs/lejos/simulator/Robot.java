package edu.mbhs.lejos.simulator;

import java.util.ArrayList;

import lejos.nxt.ColorSensor;
import lejos.nxt.NXTRegulatedMotor;
import edu.mbhs.lejos.simulator.decoration.RobotDecoration;

/**
 * Defines a robot (in a very limited sense). Each robot consists of two powered
 * wheels positioned parallel to each other, any number of supported sensors,
 * and any number of decorative (non-mobile) parts. The center of the robot is
 * considered to be the point midway between the wheels. All other positions are
 * relative to this point. The robot's angle is the angle between the line from
 * it's left wheel to it right wheel and the environment's positive x axis.
 * 
 * @author dakaufma
 */
public class Robot {
	/** Position of the robot's center relative to its environment */
	private float x, y;
	
	public void setPosition(float x, float y) {//FIXME delete this method after MouseTestThread is deleted
		this.x = x;
		this.y = y;
	}
	
	/**
	 * Angle in radians between the environment's positive x axis and the line
	 * from the left wheel to the right wheel
	 */
	private float angle;
	/** Distance between the two wheels */
	private float d;
	/**
	 * The signed distance (forward) traveled by each wheel per complete forward
	 * rotation
	 */
	private float lScale, rScale;
	/** The left and right motors in the drive system */
	private NXTRegulatedMotor left, right;
	/**
	 * The techometer counts for the two motors last time they were read by the
	 * simulator
	 */
	private float lastTechoLeft, lastTechoRight;

	private ArrayList<RobotDecoration> decorations;

	private ArrayList<PositionedColorSensor> colorSensors;
	private Environment environment = null;

	/**
	 * Creates a new robot with the following initialization values.
	 * 
	 * @param x
	 *            the initial x-coordinate relative to the environment
	 * @param y
	 *            the initial y-coordinate relative to the environment
	 * @param angle
	 *            the initial angle (radians) relative to the environment's
	 *            positive x-axis
	 * @param d
	 *            the distance between the robot's two wheels
	 * @param lScale
	 *            the (signed) distance traveled by the left wheel per rotation
	 *            of the left wheel
	 * @param rScale
	 *            the (signed) distance traveled by the right wheel per rotation
	 *            of the right wheel
	 * @param left
	 *            the left motor
	 * @param right
	 *            the right motor
	 */
	public Robot(float x, float y, float angle, float d, float lScale,
			float rScale, NXTRegulatedMotor left, NXTRegulatedMotor right) {
		this.x = x;
		this.y = y;
		this.angle = angle;
		this.d = d;
		this.lScale = lScale;
		this.rScale = rScale;
		this.left = left;
		this.right = right;

		decorations = new ArrayList<RobotDecoration>();
		colorSensors = new ArrayList<Robot.PositionedColorSensor>();
	}

	public void move(float dt) {
		left.move(dt);
		right.move(dt);
		float techoLeft = left.getExactPosition(), techoRight = right
				.getExactPosition();
		float dl = lScale * (techoLeft - lastTechoLeft) / 360, dr = rScale
				* (techoRight - lastTechoRight) / 360;
		lastTechoLeft = techoLeft;
		lastTechoRight = techoRight;
		
		if (Math.abs(dl-dr)<0.0001f) {
//			System.out.println("Straight");
			// robot is moving in a line
			float newX = x + dl * (float) Math.cos(angle + Math.PI / 2);
			float newY = y + dl * (float) Math.sin(angle + Math.PI / 2);

			x = newX;
			y = newY;
			// angle = angle;
		} else {
//			System.out.println("Curve");
			// robot is moving in a circle

			// compute current wheel locations
			float currentLX = x - d / 2 * (float) Math.cos(angle);
			float currentLY = y - d / 2 * (float) Math.sin(angle);
			float currentRX = x + d / 2 * (float) Math.cos(angle);
			float currentRY = y + d / 2 * (float) Math.sin(angle);

			// compute center of rotation
			float r = d * dl / (dr - dl);// distance {along the vector from R to
											// L} to get from L to center
			float rToLX = currentLX - currentRX, rToLY = currentLY
					- currentRY;
			float rToLMag = d;
			rToLX /= rToLMag;
			rToLY /= rToLMag;//change to unit vector
			float rotationCenterX = currentLX + (rToLX * r);
			float rotationCenterY = currentLY + (rToLY * r);

			// compute rotation angle = dl/{dist center to L motor}
			float dAngle = dl / r;

			// compute new L, R locations with rotation matrix [[cos -sin][sin cos]]
			currentLX -= rotationCenterX;
			currentRX -= rotationCenterX;
			currentLY -= rotationCenterY;
			currentRY -= rotationCenterY;
			float finalLX = (float)(currentLX * Math.cos(dAngle) - currentLY * Math.sin(dAngle)) + rotationCenterX;
			float finalLY = (float)(currentLY * Math.cos(dAngle) + currentLX * Math.sin(dAngle)) + rotationCenterY;
			float finalRX = (float)(currentRX * Math.cos(dAngle) - currentRY * Math.sin(dAngle)) + rotationCenterX;
			float finalRY = (float)(currentRY * Math.cos(dAngle) + currentRX * Math.sin(dAngle)) + rotationCenterY;
			currentLX += rotationCenterX;
			currentRX += rotationCenterX;
			currentLY += rotationCenterY;
			currentRY += rotationCenterY;
			
			// compute new x,y and angle
			x = (finalLX + finalRX) / 2;
			y = (finalLY + finalRY) / 2;
			angle = (float) Math.atan2(finalRY - finalLY, finalRX
					- finalLX);
		}
	}

	public float getX() {
		return x;
	}

	public float getY() {
		return y;
	}

	public float getAngle() {
		return angle;
	}

	public float getD() {
		return d;
	}

	public void addDecoration(RobotDecoration decoration) {
		decorations.add(decoration);
	}

	public ArrayList<RobotDecoration> getDecorations() {
		return decorations;
	}

	public void addColorSensor(ColorSensor colorSensor, int xOffset, int yOffset) {
		colorSensors.add(new PositionedColorSensor(colorSensor, xOffset, yOffset));
		colorSensor.setRobot(this);
	}
	
	public void setEnvironment(Environment environment) {
		this.environment = environment;
	}

	/**
	 * Finds the color sensor in the internal list of registered color sensors (see {@linkplain #addColorSensor(ColorSensor, int, int)}). Checks the color of the environment's background image under the color sensor and returns the color.
	 * @param colorSensor the color sensor
	 * @return the color under the color sensor if the sensor is over the background image, white if it is out of range, or null if the color sensor isn't registered.
	 */
	public ColorSensor.Color getRawColor(ColorSensor colorSensor) {
		PositionedColorSensor c = null;
		for (int i=0;i<colorSensors.size();i++) {
			if (colorSensor.equals(colorSensors.get(i).colorSensor)) {
				c = colorSensors.get(i);
				break;
			}
		}
		if (c==null)
			return null;
		
		double x = this.x + c.xOffset * Math.cos(angle) - c.yOffset * Math.sin(angle);
		double y = this.y + c.yOffset * Math.cos(angle) + c.xOffset * Math.sin(angle);
		
		java.awt.Color awtColor = environment.getColor(x,y);
		int r = awtColor.getRed();
		int g = awtColor.getGreen();
		int b = awtColor.getBlue();
		return new ColorSensor.Color(r, g, b, (r+g+b)/3);
	}

	/**
	 * Data structure containing a color sensor and an offset from the robot's
	 * center. Class is immutable. Instances are considered to be equal to other
	 * instances wrapping the same color sensor and to the color sensor itself.
	 * 
	 * @author dakaufma
	 */
	private class PositionedColorSensor {
		private ColorSensor colorSensor;
		private int xOffset, yOffset;

		public PositionedColorSensor(ColorSensor colorSensor, int xOffset, int yOffset) {
			this.colorSensor = colorSensor;
			this.xOffset = xOffset;
			this.yOffset = yOffset;
		}
		
		@Override
		public boolean equals(Object o) {
			if (o instanceof ColorSensor)
				return colorSensor.equals(o);
			else if (o instanceof PositionedColorSensor)
				return colorSensor.equals(((PositionedColorSensor)o).colorSensor);
			return false;
		}
	}
}
