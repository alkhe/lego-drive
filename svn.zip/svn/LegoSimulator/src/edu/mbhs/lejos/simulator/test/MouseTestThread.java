package edu.mbhs.lejos.simulator.test;

import java.awt.Dimension;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

import javax.swing.JFrame;

import lejos.nxt.ColorSensor;
import lejos.nxt.ColorSensor.Color;
import lejos.nxt.Motor;
import lejos.nxt.NXTRegulatedMotor;
import lejos.nxt.SensorPort;
import edu.mbhs.lejos.simulator.Robot;
import edu.mbhs.lejos.simulator.decoration.FrameDecoration;

/**
 * Moves the robot to the location of the mouse.
 * @author dakaufma
 */
public class MouseTestThread extends RobotTesterThread implements MouseMotionListener {
	private Robot robot;
	private long moveTime;
	private ColorSensor colorSensor;
	private NXTRegulatedMotor leftMotor, rightMotor;
	private float lScale, rScale;
	private JFrame frame;

	public MouseTestThread(JFrame frame) {
		this(frame, 15240);
	}
	
	public MouseTestThread(JFrame frame, long moveTime) {
		this.frame = frame;
		this.moveTime = moveTime;
		leftMotor = Motor.A;
		rightMotor = Motor.B;
		lScale = 5;
		rScale = 5;//each wheel has a circumference of 5 cm
		colorSensor = new ColorSensor(SensorPort.S1);
		robot = new Robot(150, 0, 0, 10, lScale, rScale, leftMotor, rightMotor);
		robot.addDecoration(new FrameDecoration(10, 20, -5, -10, java.awt.Color.WHITE));
		robot.addColorSensor(colorSensor, 0, 0);//center of robot
		
		frame.getContentPane().addMouseMotionListener(this);
	}
	
	@Override
	public Robot getRobot() {
		return robot;
	}

	@Override
	public void run() {
		Thread colorThread = new Thread(new Runnable() {
			public void run() {
				while (!isInterrupted()) {
					Color c = colorSensor.getColor();
					System.out.println(c.getRed() + "\t" + c.getGreen() + "\t" + c.getBlue());
					try {Thread.sleep(10);}
					catch (InterruptedException e) {
						break;
					}
				}
			}
		});
		colorThread.start();
		leftMotor.setSpeed(0);
		rightMotor.setSpeed(0);
		leftMotor.forward();
		rightMotor.forward();
		boolean test = true;
		while(test) {
			try {
				Thread.sleep(moveTime);
			} catch (InterruptedException e) { }
		}
		leftMotor.stop();
		rightMotor.stop();
	}

	@Override
	public Dimension getDesiredEnvironmentSize() {
		return new Dimension(500,500);
	}

	@Override
	public void mouseDragged(MouseEvent arg0) {
		mouseMoved(arg0);
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		Dimension size = frame.getContentPane().getSize();
		int x = e.getX();
		int y = size.height - e.getY();
		//FIXME scale screen pixels to cm
		robot.setPosition(x, y);
		
	}

}
