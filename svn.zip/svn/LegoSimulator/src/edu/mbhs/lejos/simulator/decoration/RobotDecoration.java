package edu.mbhs.lejos.simulator.decoration;

import java.awt.Graphics2D;

/**
 * Represents a purely visual component of the robot. Besides a Robot's
 * RobotDecorations, the robot is not displayed in the simulator so it is
 * recommended that all robots use at least one decoration to indicate their
 * position in the rendered environment.
 * 
 * @author dakaufma
 */
public abstract interface RobotDecoration {
	public abstract void renderDecoration(Graphics2D g);
}
