package edu.mbhs.lejos.simulator.test;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

public class SimpleRobotTester {
	public static void main(String[] args) throws IOException {
		//set up frame
		JFrame frame = new JFrame("Simple Robot Tester");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//set up robot code
		RobotTesterThread test;
		test = new LineTestThread();
//		test = new CircleTestThread();
//		test = new MouseTestThread(frame);
		
		//load background image
		BufferedImage background = ImageIO.read(new File("images/City Diagram With Arrows.jpg"));
		float cmPerMapPixel = 42 * 30.48f / background.getWidth();//42 feet * 30.48cm/ft; measured from width
		
		//create tester panel, add to frame
		SimpleRobotPanel panel = new SimpleRobotPanel(test, background, cmPerMapPixel);
		frame.getContentPane().add(panel);
		
		//display
		frame.pack();
		frame.setVisible(true);
	}
}
