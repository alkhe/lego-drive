package edu.mbhs.lejos.simulator.decoration;

import java.awt.Color;
import java.awt.Graphics2D;

/**
 * Draws the robot's frame.
 * @author dakaufma
 */
public class FrameDecoration implements RobotDecoration {
	private int width, height;
	private int xOffset, yOffset;
	private Color frameColor;
	
	/**
	 * Creates a black frame with the specified dimensions
	 * @param width with in cm
	 * @param height height in cm
	 * @param xOffset the x offset of the upper left hand corner of the frame from the robot's origin
	 * @param yOffset the y offset of the upper left hand corner of the frame from the robot's origin
	 */
	public FrameDecoration(int width, int height, int xOffset, int yOffset) {
		this(width, height, xOffset, yOffset, Color.BLACK);
	}
	
	/**
	 * Creates a frame with the specified dimensions and color
	 * @param width with in cm
	 * @param height height in cm
	 * @param xOffset the x offset of the upper left hand corner of the frame from the robot's origin
	 * @param yOffset the y offset of the upper left hand corner of the frame from the robot's origin
	 * @param c the frame's color
	 */
	public FrameDecoration(int width, int height, int xOffset, int yOffset, Color c) {
		this.width = width;
		this.height = height;
		this.xOffset = xOffset;
		this.yOffset = yOffset;
		this.frameColor = c;
	}
	
	@Override
	public void renderDecoration(Graphics2D g) {
		g.setColor(frameColor);
		g.drawRect(xOffset, yOffset, width, height);
	}

}
