package edu.mbhs.lejos.simulator.test;

import java.awt.Dimension;

import lejos.nxt.ColorSensor;
import lejos.nxt.ColorSensor.Color;
import lejos.nxt.Motor;
import lejos.nxt.NXTRegulatedMotor;
import lejos.nxt.SensorPort;
import edu.mbhs.lejos.simulator.Robot;
import edu.mbhs.lejos.simulator.decoration.FrameDecoration;

/**
 * Tests robot movement by moving the robot in a circle and stopping.
 * @author dakaufma
 */
public class CircleTestThread extends RobotTesterThread {
	private Robot robot;
	private float radius;
	private NXTRegulatedMotor leftMotor, rightMotor;
	private ColorSensor colorSensor;
	private float lScale, rScale;
	private float speed;
	private float d;
	
	public CircleTestThread() {
		this(50);
	}
	
	public CircleTestThread(float radius) {
		this.radius = radius;
		leftMotor = Motor.A;
		rightMotor = Motor.B;
		lScale = 5;
		rScale = 5;//each wheel has a circumference of 5 cm
		speed = 10;//cm per second
		d = 10;
		colorSensor = new ColorSensor(SensorPort.S1);
		robot = new Robot(150, 150, 0, d, lScale, rScale, leftMotor, rightMotor);
		robot.addDecoration(new FrameDecoration(10, 20, -5, -10, java.awt.Color.WHITE));
		robot.addColorSensor(colorSensor, 0, 0);//center of robot
	}
	
	@Override
	public Robot getRobot() {
		return robot;
	}

	@Override
	public void run() {
		//speed = speed at center of robot = radius
		float totalTime = 2*(float)Math.PI * (radius) / speed;
		leftMotor.setSpeed(2*(float)Math.PI*(radius+d/2)/totalTime * 360/lScale);
		rightMotor.setSpeed(2*(float)Math.PI*(radius-d/2)/totalTime * 360/rScale);
		leftMotor.forward();
		rightMotor.forward();
		Thread colorThread = new Thread(new Runnable() {
			public void run() {
//				String colorNames[] = {"None", "Red", "Green", "Blue", "Yellow",
//                        "Megenta", "Orange", "White", "Black", "Pink",
//                        "Grey", "Light Grey", "Dark Grey", "Cyan"};
				while (!isInterrupted()) {
//					int color = colorSensor.getColorID();
//					String colorName = colorNames[color + 1];
//					System.out.print(colorName+"\t");
					Color c = colorSensor.getColor();
					System.out.println(c.getRed() + "\t" + c.getGreen() + "\t" + c.getBlue());
					try {Thread.sleep(10);}
					catch (InterruptedException e) {
						break;
					}
				}
			}
		});
		colorThread.start();
		try {
			Thread.sleep((long)(totalTime*1000));
		} catch (InterruptedException e) { }
		colorThread.interrupt();
		leftMotor.stop();
		rightMotor.stop();
	}

	@Override
	public Dimension getDesiredEnvironmentSize() {
		return new Dimension(500,500);
	}

}
