package edu.mbhs.lejos.simulator.test;

import java.awt.Dimension;

import edu.mbhs.lejos.simulator.Robot;

/**
 * A class intended to test a complete robot/code setup. The thread's run()
 * method should invoke the main method of the leJOS code being simulated and
 * the getRobot() method should return the Robot the simulator should associate
 * with that code.
 * 
 * @author dakaufma
 * 
 */
public abstract class RobotTesterThread extends Thread {
	/**
	 * @return a Robot for the simulator to use with the simulated code
	 */
	public abstract Robot getRobot();
	
	/**
	 * Starts the simulated robot code.
	 */
	public abstract void run();
	
	/**
	 * @return the desired environment size in cm
	 */
	public abstract Dimension getDesiredEnvironmentSize();
}
