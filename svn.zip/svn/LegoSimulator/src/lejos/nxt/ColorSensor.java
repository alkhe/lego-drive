package lejos.nxt;

import edu.mbhs.lejos.simulator.Robot;

public class ColorSensor implements SensorConstants {

	private Robot robot;
	private int floodLightColor;
	private boolean floodlightOn;

	/**
	 * Create a new Color Sensor instance and bind it to a port.
	 * 
	 * @param port
	 *            the port
	 */
	public ColorSensor(SensorPort port) {
		this(port, Color.WHITE);
	}

	/**
	 * Create a new Color Sensor instance and bind it to a port. Set the
	 * floodlight to the specified color.
	 * 
	 * @param port
	 *            the port
	 * @param color
	 *            the floodlight's color
	 */
	public ColorSensor(SensorPort port, int color) {
		setFloodlight(color);
	}

	/**
	 * Does nothing in the simulator. Original docs: call this method when the
	 * light sensor is reading the high value - used by readValue
	 */
	public void calibrateHigh() {
	}

	/**
	 * Does nothing in the simulator. Original docs: call this method when the
	 * light sensor is reading the high value - used by readValue
	 */
	public void calibrateLow() {
	}

	/**
	 * Return a Color Object that contains the calibrated color readings. Note
	 * that the simulator doesn't normalize readings.
	 */
	public ColorSensor.Color getColor() {
		return getRawColor();
	}

	private static int _getColorID(int red, int green, int blue, int blank) {
		if (red > blue && red > green) {
			// red dominant color
			if (red < 65 || (blank < 40 && red < 110))
				return lejos.robotics.Color.BLACK;
			if (((blue >> 2) + (blue >> 3) + blue < green) &&
					((green << 1) > red))
				return lejos.robotics.Color.YELLOW;
			if ((green << 1) - (green >> 2) < red)
				return lejos.robotics.Color.RED;
			if (blue < 70 || green < 70 || (blank < 140 && red < 140))
				return lejos.robotics.Color.BLACK;
			return lejos.robotics.Color.WHITE;
		}
		else if (green > blue)
		{
			// green dominant color
			if (green < 40 || (blank < 30 && green < 70))
				return lejos.robotics.Color.BLACK;
			if ((blue << 1) < red)
				return lejos.robotics.Color.YELLOW;
			if ((red + (red >> 2)) < green ||
					(blue + (blue>>2)) < green )
				return lejos.robotics.Color.GREEN;
			if (red < 70 || blue < 70 || (blank < 140 && green < 140))
				return lejos.robotics.Color.BLACK;
			return lejos.robotics.Color.WHITE;
		}
		else
		{
			// blue dominant color
			if (blue < 48 || (blank < 25 && blue < 85))
				return lejos.robotics.Color.BLACK;
			if ((((red*48) >> 5) < blue && ((green*48) >> 5) < blue) ||
					((red*58) >> 5) < blue || ((green*58) >> 5) < blue)
				return lejos.robotics.Color.BLUE;
			if (red < 60 || green < 60 || (blank < 110 && blue < 120))
				return lejos.robotics.Color.BLACK;
			if ((red + (red >> 3)) < blue || (green + (green >> 3)) < blue)
				return lejos.robotics.Color.BLUE;
			return lejos.robotics.Color.WHITE;
		}
	}
	
	/**
	 * Read the current color and return an enumeration constant.
	 */
	public int getColorID() {
		// The following algorithm comes from the 1.29 Lego firmware.
		Color c = getColor();
		int red = c.getRed();
		int green = c.getGreen();
		int blue = c.getBlue();
		int blank = c.getBackground();//The general light value; not color specific
		
		return ColorSensor._getColorID(red, green, blue, blank);
	}

	/**
	 * Returns the color of the floodlight, including Color.NONE. Note that the
	 * floodlight doesn't affect the simulator's readings.
	 */
	public int getFloodlight() {
		return floodLightColor;
	}

	/**
	 * @return 100; the simulator doesn't normalize values
	 */
	public int getHigh() {
		return 100;
	}

	/**
	 * Return the calibrated light reading.
	 */
	public int getLightValue() {
		return getRawLightValue();
	}

	/**
	 * @return 0; the simulator doesn't normalize values
	 */
	public int getLow() {
		return 0;
	}

	/**
	 * Return the normalized light level.
	 */
	public int getNormalizedLightValue() {
		return getRawLightValue();
	}

	/**
	 * Return a Color Object that contains the raw color readings.
	 */
	public ColorSensor.Color getRawColor() {
		return robot.getRawColor(this);
	}

	/**
	 * Return the Raw light reading.
	 */
	public int getRawLightValue() {
		ColorSensor.Color c = getRawColor();
		float[] hsb = new float[3];
		java.awt.Color.RGBtoHSB(c.getRed(), c.getGreen(), c.getBlue(), hsb);
		return (int)(hsb[2]*255);
	}

	/**
	 * Checks if the floodlight is currently on. Note that the floodlight
	 * doesn't affect the simulator's readings.
	 */
	public boolean isFloodlightOn() {
		return floodlightOn;
	}

	/**
	 * Turns the default LED light on or off. Note that the floodlight doesn't
	 * affect the simulator's readings.
	 * 
	 * @param floodlight
	 *            true for on, false for off
	 */
	public void setFloodlight(boolean floodlight) {
		floodlightOn = floodlight;
	}

	/**
	 * Used to turn on or off the floodlight by color. Note that in the
	 * simulator flood light color makes no difference in the final reading.
	 * 
	 * @param color
	 *            the color
	 */
	public void setFloodlight(int color) {
		floodLightColor = color;
	}

	/**
	 * No calibration is done in the simulator. Original documentation: <br/>
	 * <br/>
	 * 
	 * set the normalized value corresponding to readValue() = 100;
	 * 
	 * @param high
	 *            the high value
	 */
	public void setHigh(int high) {
	}

	/**
	 * No calibration is done in the simulator. Original documentation: <br/>
	 * <br/>
	 * 
	 * set the normalized value corresponding to readValue() = 0;
	 * 
	 * @param low
	 *            the low value
	 */
	public void setLow(int low) {
	}

	/**
	 * Unlike the original class, does not include a background reading. Calls
	 * to those methods will return the foreground color.
	 * 
	 * @author dakaufma
	 */
	public static class Color extends lejos.robotics.Color {

		/**
		 * Creates the color. Background is ignored; background methods will
		 * apply to the foreground
		 * 
		 * @param red
		 *            red
		 * @param green
		 *            green
		 * @param blue
		 *            blue
		 * @param background
		 *            unused
		 * @param colorId
		 */
		public Color(int red, int green, int blue, int background, int colorId) {
			super(red, green, blue, colorId);
		}
		
		/**
		 * Determines the colorID automatically. See {@linkplain #ColorSensor(int, int, int, int, int)}
		 */
		public Color(int red, int green, int blue, int background) {
			this(red, green, blue, background, _getColorID(red, green, blue, background));
		}

		/**
		 * @return the brightness (red+green+blue)/3
		 */
		public int getBackground() {
			return (getRed()+getGreen()+getBlue())/3;
		}
	}
	
	/**
	 * Simulator-only method. Must be called first for other methods to work in the simulator.
	 * @param r the robot this sensor is attached to.
	 */
	public void setRobot(Robot r) {
		this.robot = r;
	}
}
