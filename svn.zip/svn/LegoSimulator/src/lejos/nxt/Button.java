package lejos.nxt;

public class Button {
	
	/**
	 * Unimplemented
	 */
	public static void waitForPress() {
		
	}
	
	/**
	 * Unimplemented
	 * @return 15
	 */
	public static int readButtons() {
		return 15;
	}

}
