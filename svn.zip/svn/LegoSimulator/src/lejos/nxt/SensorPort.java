package lejos.nxt;

public class SensorPort {
	public static final SensorPort S1 = new SensorPort(0);
	public static final SensorPort S2 = new SensorPort(1);
	public static final SensorPort S3 = new SensorPort(2);
	public static final SensorPort S4 = new SensorPort(3);
	
	private int id;
		
	private SensorPort(int id) {
		this.id = id;
	}
	
	public boolean equals(Object o) {
		return ((o instanceof SensorPort) && ((SensorPort)o).id==id);
	}
}
