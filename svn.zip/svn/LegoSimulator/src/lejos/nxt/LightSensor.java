package lejos.nxt;


import edu.mbhs.lejos.simulator.Robot;

/**
 * Total hack. This class is implemented on top of the ColorSensor class. To
 * appropriately model the actual color sensor values, it identifies the color
 * (red, green, etc) and returns experimentally determined constants (not
 * expected to be the same for future applications). Calibration methods are not
 * implemented. Many apologies to anyone who used to want to reuse this code.
 * 
 * @author dakaufma
 * 
 */
public class LightSensor implements SensorConstants {
	private ColorSensor colorSensor;

	public LightSensor(SensorPort port) {
		colorSensor = new ColorSensor(port);
	}

	public void setRobot(Robot r) {
		colorSensor.setRobot(r);
	}

	public int getLightValue() {
		switch (colorSensor.getColorID()) {
		case SensorConstants.BLACK:
			return 30;
		case SensorConstants.BLUE:
			return 38;
		case SensorConstants.WHITE:
			return 52;
		case SensorConstants.RED:
			return 50;
		case SensorConstants.YELLOW:
			return 53;
		case SensorConstants.GREEN://FIXME: Color vs. SensorConstants -- which is right?
			return 51;// not even measured; just a guess
		default:
			return 29;
		}
	}

	public ColorSensor getColorSensor() {
		return colorSensor;
	}
}
