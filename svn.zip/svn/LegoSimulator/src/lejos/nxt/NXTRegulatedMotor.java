package lejos.nxt;

/**
 * The simulator's version of the NXTRegulatedMotor class. Note that not all
 * methods from the original class are implemented and that some methods might
 * be modified slightly.
 * 
 * @author dakaufma
 */
public class NXTRegulatedMotor {
	public static NXTRegulatedMotor A = new NXTRegulatedMotor();
	public static NXTRegulatedMotor B = new NXTRegulatedMotor();
	public static NXTRegulatedMotor C = new NXTRegulatedMotor();

	/** Note that this values is signed */
	private float speed;
	private boolean isMoving;
	/**
	 * Note that the actual count is an int, but since dt can be small we need
	 * to keep track of "partial" counts to know when a full count has occurred.
	 */
	private float realTachoCount, tachoOffset;
	private int acceleration = 6000;//I think this is the default value
	private boolean positionControl;//true if the most recent command was a rotate command; false if not
	private float commandedDegrees, startDegrees;
	private int POSITION_CONTROL_SPEED = 100;//degrees per second; arbitrarily chosen

	/**
	 * Unlike in the original class, no public constructor is provided. Three
	 * instances of NXTRegulatedMotor (A, B, and C) will be accessible as class
	 * constants.
	 */
	private NXTRegulatedMotor() {
		isMoving = false;
		speed = 0;
		realTachoCount = 0;
		tachoOffset = 0;
		positionControl = false;
	}

	// unimplemented:
	// void addListener(RegulatedMotorListener listener) {}

	/**
	 * Causes motor to rotate backwards until stop() or flt() is called.
	 */
	public void backward() {
		isMoving = true;
		speed = -Math.abs(speed);
		positionControl = false;
	}

	/**
	 * In the original, sets the motor to float. In the simulator, equivalent to
	 * stop();
	 */
	public void flt() {
		stop();
	}

	// unimplemented; the documentation is the same as in flt() and I don't know
	// what it does differently
	// void flt(boolean immediateReturn) {}

	/**
	 * Causes motor to rotate forward until stop() or flt() is called.
	 */
	public void forward() {
		isMoving = true;
		speed = Math.abs(speed);
		positionControl = false;
	}

	// unimplemented; changes in velocity are instantaneous
	public int getAcceleration() {
		return acceleration;
	}

	// unimplemented; I'm not implementing position-based control unless we
	// actually need it
	// public int getLimitAngle() {}

	// unimplemented; the simulator has no max speed. Either way, speed isn't a
	// problem for this contest
	// public float getMaxSpeed() {}

	// unimplmented; docs say it returns the current DESIRED position, but we
	// aren't doing position control
	// public int getPosition()

	/**
	 * @return the current velocity in degrees per second.
	 */
	public int getRotationSpeed() {
		return (int) speed;// TODO make sure this returns a signed value
	}

	/**
	 * @return the current target speed, which, in the simulator, is the same as
	 *         the current speed.
	 */
	public int getSpeed() {
		if (positionControl) {
			if ((((realTachoCount > startDegrees) == (realTachoCount > commandedDegrees)) && realTachoCount!=startDegrees) || startDegrees==commandedDegrees) {
				//overshot; set position exactly and make speed 0
				realTachoCount = commandedDegrees;
				positionControl = false;
				return 0;
			}
			else {
				return POSITION_CONTROL_SPEED * ((startDegrees>commandedDegrees)?-1:1);
			}
		}
		else {
			return (isMoving ? (int) speed : 0);
		}
	}

	/**
	 * @return the tachometer count (one count per degree).
	 */
	public int getTachoCount() {
		return (int) (realTachoCount + tachoOffset);
	}

	/**
	 * @return true if the motor is attempting to rotate.
	 */
	public boolean isMoving() {
		return isMoving && speed != 0;
	}

	// unimplemented; never needed for our problem and motors are never stalled
	// in the simulator anyway
	// public boolean isStalled() {}

	/**
	 * Reset the tachometer associated with this motor.
	 */
	public void resetTachoCount() {
		tachoOffset = -realTachoCount;
		positionControl = false;
	}

	public void rotate(int angle, boolean returnImmediately) {
		positionControl = true;
		startDegrees = realTachoCount;
		commandedDegrees = startDegrees+angle;
		if (!returnImmediately)
			while (commandedDegrees!=realTachoCount && positionControl) {
				try {Thread.sleep(20);}
				catch (InterruptedException e) {
					return;
				}
			}
	}
	
	public void rotate(int angle) {
		rotate(angle, false);
	}

	// unimplemented; no position-based control
	// public void rotate(int angle, boolean immediateReturn) {}

	// unimplemented; no position-based control
	// public void rotateTo(int limitAngle) {}

	// unimplemented; no position-based control
	// public void rotateTo(int limitAngle, boolean immediateReturn) {}

	// unimplemented; changes in velocity are intantaneous
	public void setAcceleration(int acceleration) {
		this.acceleration = acceleration;
	}

	/**
	 * Sets desired motor speed, in degrees per second. In the original, the
	 * maximum reliably sustainable velocity was 100 x battery voltage under
	 * moderate load, such as a direct drive robot on the level, but the
	 * simulator has no maximum speed.
	 * 
	 * @param speed
	 *            the speed
	 */
	public void setSpeed(float speed) {
		this.speed = speed;
		positionControl = false;
	}

	/**
	 * Sets desired motor speed, in degrees per second. In the original, the
	 * maximum reliably sustainable velocity was 100 x battery voltage under
	 * moderate load, such as a direct drive robot on the level, but the
	 * simulator has no maximum speed.
	 * 
	 * @param speed
	 *            the speed
	 */
	public void setSpeed(int speed) {
		setSpeed((float) speed);
		positionControl = false;
	}

	// unimplemented; motors don't stall in the simulator
	// public void setStallThreshold(int error, int time) {}

	/**
	 * Causes motor to stop instantaneously.
	 */
	public void stop() {
		isMoving = false;
		positionControl = false;
	}

	/**
	 * Causes motor to stop. Parameter is ignored; all stops are instantaneous.
	 */
	public void stop(boolean returnImmediately) {
		stop();
	}
	
	// unimplemented; motors must be regulated
	// public boolean suspendRegulation

	// unimplemented; not relevant with instantaneous speed-based control
	// public void waitComplete() {}

	/**
	 * NOT from the original class; should only be called by the simulator.<br/>
	 * 
	 * @return the exact number of degrees the motor has rotated off of its
	 *         starting position.
	 */
	public float getExactPosition() {
		return realTachoCount;
	}

	/**
	 * NOT from the original class; should only be called from the simulator.<br/>
	 * Simulates progressing through time by the provided amount of time.
	 * 
	 * @param dt
	 *            the time change since the last time this method was called.
	 */
	public void move(float dt) {
		// update real tacho count
		realTachoCount += getSpeed() * dt;
	}
}
