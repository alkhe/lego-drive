package lejos.nxt;

/**
 * This is the simulator's version of the Motor class. It contains all
 * functionality of the original Motor class.
 * 
 * @author dakaufma
 */
public class Motor {
	public static NXTRegulatedMotor A = NXTRegulatedMotor.A;
	public static NXTRegulatedMotor B = NXTRegulatedMotor.B;
	public static NXTRegulatedMotor C = NXTRegulatedMotor.C;
}
