import lejos.nxt.ColorSensor;
import lejos.nxt.Sound;
import lejos.robotics.subsumption.Behavior;

/**
 * Behavior to turn away from side lines using the color sensor
 * @author julianboilen
 *
 */
public class AvoidSideLinesBehavior implements Behavior {

	private boolean suppressed;
	private final double TURN_RATE = 100;

	public void action() {
		suppressed = false;
		
		if (Configuration.SOUND_ON) Sound.beep();
		System.out.println("Avoiding side line");
		
		
		while (!suppressed){
			if (leftSensed()){
				AvoidLines.pilot.steer(TURN_RATE);
			} else if (rightSensed()){
				AvoidLines.pilot.steer(-TURN_RATE);
			}
			else//no more line, end of behavior
				break;
		}
		AvoidLines.pilot.stop();

	}

	public void suppress() {
		// TODO Auto-generated method stub
		suppressed = true;
	}

	public boolean takeControl() {
		// TODO Auto-generated method stub
		return leftSensed() || rightSensed();
	}
	private boolean leftSensed(){
		return AvoidLines.lColorSensor.getColorID() == ColorSensor.Color.WHITE;
	}
	private boolean rightSensed(){
		return AvoidLines.rColorSensor.getColorID() == ColorSensor.Color.WHITE;
	}

}
