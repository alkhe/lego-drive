import lejos.nxt.ColorSensor;
import lejos.robotics.navigation.DifferentialPilot;
import lejos.robotics.subsumption.Arbitrator;
import lejos.robotics.subsumption.Behavior;

/**
 * A base program for a differential drive robot using Behaviors
 * @author julianboilen
 *
 */
public class AvoidLines {

	/**
	 * The Pilot to control the robot
	 */
	public static DifferentialPilot pilot;
	public static ColorSensor lColorSensor = new ColorSensor(Configuration.LEFT_COLOR_SENSOR_PORT);
	public static ColorSensor rColorSensor = new ColorSensor(Configuration.RIGHT_COLOR_SENSOR_PORT);
	public static ColorSensor fColorSensor = new ColorSensor(Configuration.FRONT_COLOR_SENSOR_PORT);
	
	AvoidLines(){
		pilot = new DifferentialPilot(Configuration.WHEEL_DIAMETER, 
				Configuration.TRACK_WIDTH, Configuration.LEFT_MOTOR, Configuration.RIGHT_MOTOR);
		//TODO: Set any defaults and preliminary stuff here like speed.
		Behavior[] behaviors = {new DefaultBehavior(), new AvoidSideLinesBehavior(), 
				new AvoidFrontLineBehavior()};
		Arbitrator arbitrator = new Arbitrator(behaviors);
		arbitrator.start();//blocking
			
	}
	public static void main(String[] args) {
		new AvoidLines();
	}

}
