import lejos.nxt.Motor;
import lejos.nxt.NXTRegulatedMotor;
import lejos.nxt.SensorPort;


public class Configuration {
	/**
	 * The wheel diameter
	 */
	public static final float WHEEL_DIAMETER = 2.25f;
	/**
	 * The distance between the wheels
	 */
	public static final float TRACK_WIDTH = 5.5f;
	/**
	 * The left motor
	 */
	public static final NXTRegulatedMotor LEFT_MOTOR = Motor.A;
	/**
	 * The right motor
	 */
	public static final NXTRegulatedMotor RIGHT_MOTOR = Motor.B;
	/**
	 * The port connecting the left color sensor
	 */
	public static final SensorPort LEFT_COLOR_SENSOR_PORT = SensorPort.S1;
	/**
	 * The port connecting the right color sensor
	 */
	public static final SensorPort RIGHT_COLOR_SENSOR_PORT = SensorPort.S2;
	/**
	 * The port connecting the front color sensor
	 */
	public static final SensorPort FRONT_COLOR_SENSOR_PORT = SensorPort.S3;
	/**
	 * Turn sounds on and off for commands that check for this setting
	 */
	public static final boolean SOUND_ON = true;
}
