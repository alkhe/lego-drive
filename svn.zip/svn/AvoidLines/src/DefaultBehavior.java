import lejos.robotics.subsumption.Behavior;

/**
 * What the robot does when no other Behaviors are active. It is probably on track and should just move forward.
 * @author julianboilen
 *
 */
public class DefaultBehavior implements Behavior {

	private boolean suppressed;

	public void action() {
		// TODO Auto-generated method stub
		suppressed = false;
		AvoidLines.pilot.forward();
		while(!suppressed)
			Thread.yield();
		AvoidLines.pilot.stop();
	}

	public void suppress() {
		// TODO Auto-generated method stub
		suppressed = true;
	}

	/**
	 * Always take control
	 */
	public boolean takeControl() {
		// TODO Auto-generated method stub
		return true;
	}

}
