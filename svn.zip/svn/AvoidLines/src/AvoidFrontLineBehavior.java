import lejos.nxt.ColorSensor;
import lejos.nxt.Sound;
import lejos.robotics.subsumption.Behavior;

/**
 * Behavior to rotate in place until front color sensor no longer sees white. Should be high priority.
 * @author julianboilen
 *
 */
public class AvoidFrontLineBehavior implements Behavior {

	private boolean suppressed;
	public void action() {
		suppressed = false;
		
		if (Configuration.SOUND_ON) Sound.beep();
		System.out.println("Avoiding front line");
		
		AvoidLines.pilot.steer(200);//start rotating in place
		while(!suppressed && frontSensed())//wait until the line is gone or suppressed
			Thread.yield();
		
		AvoidLines.pilot.stop();
	}

	public void suppress() {
		// TODO Auto-generated method stub
		suppressed = true;
	}

	public boolean takeControl() {
		// TODO Auto-generated method stub
		return frontSensed();
	}
	private boolean frontSensed(){
		return AvoidLines.fColorSensor.getColorID() == ColorSensor.Color.WHITE;
	}
}
