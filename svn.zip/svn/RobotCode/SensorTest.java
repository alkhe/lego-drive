import lejos.nxt.ColorSensor;
import lejos.nxt.LightSensor;
import lejos.nxt.LCD;
import lejos.nxt.SensorPort;
import lejos.robotics.Color;
import lejos.robotics.RegulatedMotor;
import lejos.robotics.navigation.DifferentialPilot;
import lejos.robotics.navigation.RotateMoveController;
import lejos.util.PilotProps;

public class SensorTest {
	
	public static void main (String[] aArg)
			throws Exception
			{
		PilotProps pp = new PilotProps();
		pp.loadPersistentValues();
		float wheelDiameter = Float.parseFloat(pp.getProperty(PilotProps.KEY_WHEELDIAMETER, "81.6"));
		float trackWidth = Float.parseFloat(pp.getProperty(PilotProps.KEY_TRACKWIDTH, "110"));
		RegulatedMotor leftMotor = PilotProps.getMotor(pp.getProperty(PilotProps.KEY_LEFTMOTOR, "A"));
		RegulatedMotor rightMotor = PilotProps.getMotor(pp.getProperty(PilotProps.KEY_RIGHTMOTOR, "B"));
		boolean reverse = Boolean.parseBoolean(pp.getProperty(PilotProps.KEY_REVERSE,"true"));

		// Change last parameter of Pilot to specify on which 
		// direction you want to be "forward" for the robot.
		// The wheel and axle dimension parameters should be
		// set, but are not critical.
		final RotateMoveController pilot = new DifferentialPilot(wheelDiameter, trackWidth, leftMotor, rightMotor, reverse);
		final ColorSensor csLeft = new ColorSensor(SensorPort.S1);
		final ColorSensor csRight= new ColorSensor(SensorPort.S2);
		final LightSensor lsMiddle= new LightSensor(SensorPort.S3);
		csLeft.setFloodlight(Color.WHITE);
		csRight.setFloodlight(Color.WHITE);
		double fastSpeed=.75;
		pilot.setRotateSpeed(180);
		boolean onTheRoad=true;	
		boolean onTheLine=true;
		int lastColor=999;
		pilot.setTravelSpeed(100);
		pilot.forward();
		String[] instructions={"s","l","l","r","r"};
		int instrCount=0;		
		while(true){
			LCD.drawString(lsMiddle.readValue()+"", 0, 0);
			onTheRoad=canSeeRoad(csRight);
			onTheLine=onWhiteLine(csRight);
			if((isAtIntersection(csLeft) || isAtIntersection(csRight)|| isAtIntersection(lsMiddle)) &&lastColor!=0){
				pilot.stop();
				Thread.sleep(5000);				
				pilot.forward();
				Thread.sleep(2000);
				if(instructions[instrCount].equals("l"))
					pilot.rotate(-90);
				else if(instructions[instrCount].equals("r"))
					pilot.rotate(90);
				pilot.forward();
				lastColor=0;	
				instrCount++;
				if(instrCount>=instructions.length)
					pilot.stop();
			}

			if(hitsWhiteLine(csRight)){
				int rMotor=(int) (200*fastSpeed);
				int lMotor=(int) (170*fastSpeed);
				leftMotor.setSpeed(lMotor);
				rightMotor.setSpeed(rMotor);
				lastColor=6;
				while(hitsWhiteLine(csRight)){
					rMotor++;
					if(lMotor>1)
					lMotor--;
					rightMotor.setSpeed(rMotor);
					leftMotor.setSpeed(lMotor);
					lastColor=6;
				}
				rightMotor.setSpeed((int) (200*fastSpeed));
				leftMotor.setSpeed((int) (200*fastSpeed));
			}
			
			if(hitsWhiteLine(csLeft)){
				int lMotor=(int) (200*fastSpeed);;
				int rMotor=(int) (170*fastSpeed);
				rightMotor.setSpeed(rMotor);
				leftMotor.setSpeed(lMotor);
				lastColor=6;
				while(hitsWhiteLine(csLeft)){
					lMotor++;
					if(rMotor>1)
					rMotor--;
					leftMotor.setSpeed(lMotor);
					rightMotor.setSpeed(rMotor);
					lastColor=6;
				}
				rightMotor.setSpeed((int) (200*fastSpeed));
				leftMotor.setSpeed((int) (200*fastSpeed));
			}
			
			if(hitsYellowLine(csRight)){
				int rMotor=115;
				int lMotor=85;
				leftMotor.setSpeed(85);
				rightMotor.setSpeed(115);
				lastColor=6;
				while(hitsYellowLine(csRight)){
					rMotor++;
					if(lMotor>1)
					lMotor--;
					rightMotor.setSpeed(rMotor);
					leftMotor.setSpeed(lMotor);
					lastColor=6;
				}
				rightMotor.setSpeed(100);
				leftMotor.setSpeed(100);
			}
			
			if(hitsYellowLine(csLeft)){
				int rMotor=115;
				int lMotor=85;
				leftMotor.setSpeed(85);
				rightMotor.setSpeed(115);
				lastColor=6;
				while(hitsYellowLine(csRight)){
					rMotor++;
					if(lMotor>1)
					lMotor--;
					rightMotor.setSpeed(rMotor);
					leftMotor.setSpeed(lMotor);
					lastColor=6;
				}
				rightMotor.setSpeed(100);
				leftMotor.setSpeed(100);
			}
			
		
			
			else if(canSeeRoad(csRight)&&lastColor==6){
				rightMotor.setSpeed(175);
				leftMotor.setSpeed(185);
			}			
			else if(canSeeRoad(csRight)&&lastColor==3){
				rightMotor.setSpeed(95);
				leftMotor.setSpeed(105);
				lastColor=3;
			}
			else{
				rightMotor.setSpeed(100);
				leftMotor.setSpeed(100);
				lastColor=6;
			}

						


		}	
		}


		private static boolean canSeeRoad(ColorSensor cs){
			ColorSensor.Color vals = cs.getColor();
			return vals.getColor()==7;	
		}

		private static boolean onWhiteLine(ColorSensor cs){
			ColorSensor.Color vals = cs.getColor();
			return vals.getColor()==6;	
		}

		private static boolean hitsWhiteLine(ColorSensor cs){
			ColorSensor.Color vals = cs.getColor();
			return vals.getColor()==6;	
		}
		

		private static boolean hitsYellowLine(ColorSensor cs){
			ColorSensor.Color vals = cs.getColor();
			return vals.getColor()==3;	
		}
		
		private static boolean isAtIntersection(ColorSensor cs){
			ColorSensor.Color vals = cs.getColor();
			return vals.getColor()==0;	
		}
		
		private static boolean isAtIntersection(LightSensor ls){
			int val = ls.readValue();
			return val<=53&&val>=47;	
		}
		
		private static boolean onBlueLine(ColorSensor cs){
		ColorSensor.Color vals = cs.getColor();
			return vals.getColor()==2;	
		}
		

		
		}



