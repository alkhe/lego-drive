
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class GraphParser {

	private Hashtable<String, Node> nodes;
	private List<Node> nodeValues;

	private Node startNode;

	public static void main(String[] args) throws IOException {
		GraphParser p = new GraphParser("weightedGraph.txt", "constants.txt", "0");
		ArrayList<String> commands = new ArrayList<String>();
		
		/*
		//load all stuff from file to test syntax
		HashMap<String, String> constants = new HashMap<String, String>();
		Scanner s = new Scanner(new File("constants.txt"));
		while (s.hasNextLine()) {
			String name = s.nextLine().trim();
			if (s.hasNextLine()) {
				String value = s.nextLine();
				constants.put(name, value);
			}
		}
		s.close();
		ArrayList<String> file = new ArrayList<String>();
		s = new Scanner(new File("graph.txt"));
		while (s.hasNextLine()) {
			String line = s.nextLine();
			for (String constant:constants.keySet())
				line = line.replaceAll(constant, constants.get(constant));
			if (line.indexOf('#')!=-1)
				line = line.substring(0, line.indexOf('#'));
			line = line.trim();
			if (!line.isEmpty())
				file.add(line);
		}
		s.close();
		String[] cmd = file.toArray(new String[file.size()]);
		//end full-file hack
		*/
		String[] cmd = p.pathTo("15");
		cmd = formatAsJavaStatement(cmd);
		for (String s1:cmd)
			commands.add(s1);
		cmd = p.pathTo("72");
		cmd = formatAsJavaStatement(cmd);
		for (String s1:cmd)
			commands.add(s1);
		cmd = p.pathTo("198");
		cmd = formatAsJavaStatement(cmd);
		for (String s1:cmd)
			commands.add(s1);
		cmd = p.pathTo("186");
		cmd = formatAsJavaStatement(cmd);
		for (String s1:cmd)
			commands.add(s1);
		cmd = p.pathTo("168");
		cmd = formatAsJavaStatement(cmd);
		for (String s1:cmd)
			commands.add(s1);
//		cmd = p.pathTo("139");
//		cmd = formatAsJavaStatement(cmd);
//		for (String s1:cmd)
//			commands.add(s1);
		cmd = p.pathTo("1");
		cmd = formatAsJavaStatement(cmd);
		for (String s1:cmd)
			commands.add(s1);


		System.out.println("{");
		for (int i=0;i<commands.size();i++) {
			if (i+1<commands.size())
				System.out.println(commands.get(i)+",");
			else
				System.out.println(commands.get(i));
		}
		System.out.println("};");
	}
	
	private static String[] formatAsJavaStatement(String[] cmd) {
		String[] result = new String[cmd.length];
		for (int i=0;i<cmd.length;i++) {
			try {
			String line = cmd[i];
			String s = "new ";
			switch (line.split("\\s+")[3].charAt(0)) {
			case 'S':
				s+="ForwardStraight";
				break;
			case 'B':
				s+="BackwardStraight";
				break;
			case 'W':
				s+="Wait";
				break;
			case 'L':
				s+="TurnLeft";
				break;
			case 'R':
				s+="TurnRight";
				break;
			default:
				System.err.println("Invalid command character \""+line.split("\\s+")[3].charAt(0)+"\" in \""+line+"\"");
				System.exit(1);
			}
			s+="(";
			String[] params = line.split("\\s+");
			for (int j=4;j<params.length;j++) {
				s+="\""+params[j]+"\"";
				if (j+1<params.length)
					s+=", ";
			}
			s+=")";
			result[i] = s;
			} catch (Exception e) {
				e.printStackTrace();
				System.err.println(cmd[i]);
				System.exit(1);
			}
		}
		return result;
	}
	
	private void ensureExistence(String... names) {
		for (String name : names)
			if (nodes.get(name) == null)
				nodes.put(name, new Node());
	}

	public GraphParser(String graph_filename, String constants_filename,
			String startNodeName) throws IOException {

		// Read substitution constants
		Scanner in = new Scanner(new FileInputStream(new File(constants_filename)));
		HashMap<String, String> substitutions = new HashMap<String, String>();

		while (in.hasNextLine()) {
			String variable = in.nextLine();
			if (in.hasNextLine()) {
				String substitution = in.nextLine();
				substitutions.put(variable, substitution);
			}
		}
		in.close(); // Close constants file
		
		// Read graph
		FileInputStream fin = new FileInputStream(new File(graph_filename));
		List<String[]> contents = new ArrayList<String[]>();
		String str = "";
		List<String> cmd = new ArrayList<String>();
		boolean comment = false;
		int val;
		while ((val = fin.read()) != -1) {
			char c = (char) val;
			comment = (comment || c == '#') && (c != '\n');
			if (comment)
				continue;
			if (c == ' ' || c == '\t' || c == '\n') {
				str = str.trim();
				if (!str.isEmpty()) {
					if (substitutions.containsKey(str))
						str = substitutions.get(str);
					cmd.add(str.trim());
				}
				str = "";
				if (c == '\n') {
					if (!cmd.isEmpty())
						contents.add(cmd.toArray(new String[cmd.size()]));
					cmd.clear();
				}
			} else
				str += c;
		}
		fin.close();
		
		// Populate table
		nodes = new Hashtable<String, Node>();
		Node from, to;
		for (String[] command : contents) {
			ensureExistence(command[0], command[1]);
			from = nodes.get(command[0]);
			to = nodes.get(command[1]);
			from.addEdge(new Edge(from, to, Float.parseFloat(command[2]),
					command));
		}

		// Close graph file
		in.close();

		// Break up map for reasons I don't have time to figure out how to say
		nodeValues = new ArrayList<Node>();
		Enumeration<String> keys = nodes.keys();
		while (keys.hasMoreElements())
			nodeValues.add(nodes.get(keys.nextElement()));

		// Set starting node
		startNode = nodes.get(startNodeName);
	}

	/**
	 * @param targetName
	 *            the desired destination
	 * @return an array of Strings, where each string represents the parameters
	 *         required to generate the robot's behavior to get to the desired
	 *         destination
	 */
	public String[] pathTo(String targetName) {

		Node target = nodes.get(targetName);

		// Reset nodes
		for (Node node : nodeValues) {
			node.reset();
		}
		startNode.setTime(0, null);

		// Dijkstra's algorithm
		Node current = startNode;
		while (true) {
			// current is the lowest unmarked vertex (or the starting vertex)
			current.mark();
			if (current == target) {
				// Found it!
				List<String> stuffToDo = new LinkedList<String>();
				do {
					Edge edge = current.getUsedEdge();
					String[] command = edge.getCommand();
					String s = "";
					for (int i=0;i<command.length;i++) {
						s+=command[i];
						if (i+1<command.length)
							s+=" ";
					}
					stuffToDo.add(s);
					
					current = edge.getStart();
				} while (current != startNode);
				startNode = target;
				
				Collections.reverse(stuffToDo);
				
				return stuffToDo.toArray(new String[stuffToDo.size()]);
			}

			// Update time for each edge if the fastest time so far is through
			// our current node
			for (Edge edge : current.getEdges()) {
				Node next = edge.getEnd();
				float time = current.getTime() + edge.getTime();
				if (time < next.getTime())
					next.setTime(time, edge);
			}

			// Find the next node
			current = null;
			float min = Float.POSITIVE_INFINITY;
			for (Node node : nodeValues) {
				float time = node.getTime();
				if (!node.isMarked() && time < min) {
					current = node;
					min = time;
				}
			}
			if (current == null)
				return null; // No path found; this should never happen if the
								// map is complete and correct.
		}
	}

	private class Node {

		private float time;
		private boolean mark;

		private Edge from;

		private List<Edge> edges;

		public void reset() {
			time = Float.POSITIVE_INFINITY;
			mark = false;
		}

		public Node() {
			edges = new ArrayList<Edge>();
		}

		public void addEdge(Edge edge) {
			edges.add(edge);
		}

		public List<Edge> getEdges() {
			return edges;
		}

		public void setTime(float t, Edge f) {
			time = t;
			from = f;
		}

		public float getTime() {
			return time;
		}

		public Edge getUsedEdge() {
			return from;
		}

		public void mark() {
			mark = true;
		}

		public boolean isMarked() {
			return mark;
		}
	}

	private class Edge {

		private String[] command;
		private Node start, end;
		private float time;

		public Edge(Node s, Node e, float t, String[] c) {
			start = s;
			end = e;
			time = t;
			command = c;
		}

		public Node getStart() {
			return start;
		}

		public Node getEnd() {
			return end;
		}

		public float getTime() {
			return time;
		}

		public String[] getCommand() {
			return command;
		}
	}
}
