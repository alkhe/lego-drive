import java.awt.Dimension;

import edu.mbhs.fuzzylogic.Constants;
import edu.mbhs.fuzzylogic.Runner;
import edu.mbhs.lejos.simulator.Robot;
import edu.mbhs.lejos.simulator.decoration.FrameDecoration;
import edu.mbhs.lejos.simulator.test.RobotTesterThread;


public class FuzzyLogicTest extends RobotTesterThread {
	private static final float INIT_X = 118;
	private static final float INIT_Y = 277;
	private static final float INIT_ANGLE = 0f;
	private Robot robot;
	
	public FuzzyLogicTest() {
		robot = new Robot(INIT_X, INIT_Y, INIT_ANGLE, Constants.WHEEL_SEPARATION, -Constants.WHEEL_CIRCUMFERENCE, -Constants.WHEEL_CIRCUMFERENCE, Runner.left, Runner.right);
		robot.addColorSensor(Runner.csLeft, -8, 9);
		robot.addColorSensor(Runner.csRight, 8, 9);
		robot.addColorSensor(Runner.lsMiddle.getColorSensor(), 0, 10);
		
		robot.addDecoration(new FrameDecoration(14, 14, -7, -7, java.awt.Color.WHITE));
	}
	
	@Override
	public Robot getRobot() {
		return robot;
	}

	@Override
	public void run() {
		Runner.main(new String[]{});
	}

	@Override
	public Dimension getDesiredEnvironmentSize() {
		return new Dimension(500,500);
	}

}
